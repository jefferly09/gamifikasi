<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LeaderboardController extends Controller
{
    function index(Request $request)
    {
        return view("main/leaderboard", [
            "title" => "Leaderboard"
        ]);
    }
}

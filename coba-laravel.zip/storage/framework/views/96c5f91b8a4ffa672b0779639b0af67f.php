
<?php $__env->startSection("title"); ?>
    <?= $title ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<div class="row">
    <div class="col-md-12">
    <div class="card">
    <div class="card-header">
    
    <h4 class="card-title">STUDENTS TABLE</h4>
    </div>
    <div class="card-body">
    <div class="table-responsive">
    <table class="table">
    <thead class="text-primary">
    <tr><th>Attendace Number</th><th>Nama</th><th>Gender</th><th class="text-center">Aksi</th></tr>
    </thead>
    <tbody>
      <tr>
          <td>1</td>
          <td>Alice</td><td>F</td>
          <td class="text-center"><button class="btn btn-danger btn-sm btn-icon" onclick="deleteUser(1)" title="Hapus"><i class="now-ui-icons ui-1_simple-remove"></i></button></td>
        </tr>
    </table>
    </div>
    </div>
    </div>
    <script>
          function deleteUser(id) {
            if (confirm('Yakin ingin menghapus user ID: ' + id + '?')) {
              alert('Data dihapus (simulasi).');
            }
          }
        </script>
    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("container", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\app\coba-laravel\resources\views/main/students.blade.php ENDPATH**/ ?>
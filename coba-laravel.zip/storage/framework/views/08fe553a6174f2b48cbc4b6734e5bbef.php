
<?php $__env->startSection("title"); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-category">Daftar Soal</h5>
                <h4 class="card-title">Tabel Soal Pilihan Ganda</h4>
                <a href="form_question">
                    <button class="btn btn-success btn-sm btn-icon">
                        <i class="now-ui-icons ui-1_simple-add"></i>
                    </button>
                </a>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>No</th>
                            <th>Pertanyaan</th>
                            <th>Opsi A</th>
                            <th>Opsi B</th>
                            <th>Opsi C</th>
                            <th>Jawaban Benar</th>
                            <th>Level</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($q->question); ?></td>
                            <td><?php echo e($q->answer_a); ?></td>
                            <td><?php echo e($q->answer_b); ?></td>
                            <td><?php echo e($q->answer_c); ?></td>
                            <td><?php echo e($q->right_answer); ?></td>
                            <td><?php echo e($q->level); ?></td>
                            <td>
                                <a href="<?php echo e(route('questions.edit', $q->id)); ?>"><button class="btn btn-warning btn-sm btn-icon">
                                    <i class="now-ui-icons ui-1_settings-gear-63"></i>
                                </button></a>
                                <form action="<?php echo e(route('questions.destroy', $q->id)); ?>" method="POST" style="display:inline;" 
                                onsubmit="return confirm('Yakin ingin menghapus soal ini?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm btn-icon">
                                        <i class="now-ui-icons ui-1_simple-remove"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("container", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\app\coba-laravel\resources\views/main/question.blade.php ENDPATH**/ ?>
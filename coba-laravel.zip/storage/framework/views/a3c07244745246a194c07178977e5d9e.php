<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h5 class="card-category">Edit Soal</h5>
          <h4 class="card-title">Form Edit Soal Pilihan Ganda (A-C)</h4>
        </div>
        <div class="card-body">
          <form method="POST" action="<?php echo e(route('questions.update', $question->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
              <label for="question">Pertanyaan</label>
              <input type="text" name="question" class="form-control" value="<?php echo e(old('question', $question->question)); ?>">
            </div>
            <div class="form-group">
              <label for="answer_a">Jawaban A</label>
              <input type="text" name="answer_a" class="form-control" value="<?php echo e(old('answer_a', $question->answer_a)); ?>">
            </div>
            <div class="form-group">
              <label for="answer_b">Jawaban B</label>
              <input type="text" name="answer_b" class="form-control" value="<?php echo e(old('answer_b', $question->answer_b)); ?>">
            </div>
            <div class="form-group">
              <label for="answer_c">Jawaban C</label>
              <input type="text" name="answer_c" class="form-control" value="<?php echo e(old('answer_c', $question->answer_c)); ?>">
            </div>
            <div class="form-group">
              <label for="right_answer">Jawaban Benar</label>
              <select class="form-control" name="right_answer">
                <option value="">Pilih jawaban benar</option>
                <option value="a" <?php echo e($question->right_answer == 'a' ? 'selected' : ''); ?>>A</option>
                <option value="b" <?php echo e($question->right_answer == 'b' ? 'selected' : ''); ?>>B</option>
                <option value="c" <?php echo e($question->right_answer == 'c' ? 'selected' : ''); ?>>C</option>
              </select>
            </div>
            <div class="form-group">
                    <label for="level">Level</label>
                    <select name="level" class="form-control" id="correctAnswer">
                      <option value="">Pilih level soal</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                    </select>
                  </div>
            <button type="submit" class="btn btn-warning mt-3">Perbarui Soal</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('container', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\app\coba-laravel\resources\views/main/form_question_edit.blade.php ENDPATH**/ ?>
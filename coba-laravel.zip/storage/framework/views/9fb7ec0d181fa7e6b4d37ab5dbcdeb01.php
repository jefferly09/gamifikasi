
<?php $__env->startSection("title"); ?>
    <?= $title ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">

                <h4 class="card-title">LEADERBOARD</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class="text-primary">
                      <tr>
                        <th>Peringkat</th>
                        <th>Nama</th>
                        <th>Skor</th>
                        
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>1</td>
                        <td>Alice</td>
                        <td>98</td>
                      </tr>
                  </table>
                </div>
              </div>
            </div>
            <script>
              function deleteUser(id) {
                if (confirm('Yakin ingin menghapus user ID: ' + id + '?')) {
                  alert('Data dihapus (simulasi).');
                }
              }
            </script>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("container", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\app\coba-laravel\resources\views/main/leaderboard.blade.php ENDPATH**/ ?>
<div class="sidebar-wrapper" id="sidebar-wrapper">
        <ul class="nav">
          
          <li>
            <a href="./leaderboard">
              <i class="now-ui-icons education_atom"></i>
              <p>Leaderboard</p>
            </a>
          </li>
         

          <li>
            <a href="./students">
              <i class="now-ui-icons users_single-02"></i>
              <p>Students Table</p>
            </a>
          </li>
          <li>
            <a href="./question">
              <i class="now-ui-icons design_bullet-list-67"></i>
              <p>Table Question</p>
            </a>
          </li>
          
        </ul>
      </div><?php /**PATH D:\app\coba-laravel\resources\views/_partials/navigation.blade.php ENDPATH**/ ?>